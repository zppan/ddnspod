from setuptools import setup

setup(
    name = "ddnspod",
    version = "0.0.3",
    packages=["ddnspod"],
    author = "zppan",
    author_email = "pzping@gmail.com",
    url = "https://github.com/zppan/ddnspod",
    description = "A simple update dnspod record.list",
)
